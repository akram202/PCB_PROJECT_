*PADS-LIBRARY-PART-TYPES-V9*

SRD-05VDC-SL-C SRD05VDCSLC I RLY 9 1 0 0 0
TIMESTAMP 2026.07.07.22.28.01
"Manufacturer_Name" EAGLE
"Manufacturer_Part_Number" SRD-05VDC-SL-C
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" SRD-05VDC-SL-C; RELAY ISO9002 1. MAIN FEATURES  Switching capacity available by 10A in spite of small size design for highdensity P.C. board mounting technique.  U
"Datasheet Link" http://www.songlerelay.com/Public/Uploads/20161104/581c81ac16e36.pdf
"Geometry.Height" 15.8mm
GATE 1 5 0
SRD-05VDC-SL-C
1 0 U COIL_1
2 0 U NO
3 0 U NC
4 0 U COIL_2
5 0 U COM

*END*
*REMARK* SamacSys ECAD Model
13996107/1888427/2.50/5/3/Relay or Contactor
